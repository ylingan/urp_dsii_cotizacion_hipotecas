# Cotizador Hipotecario — Arquitectura Hexagonal (Java + Spring Boot)

Para ejecutar: `mvn spring-boot:run` y probar: `curl "http://localhost:8080/cotizaciones?monto=250000&plazoMeses=240&tipoCliente=PREMIUM"`.
