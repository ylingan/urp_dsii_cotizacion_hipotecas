package com.banco.cotizador.dominio.puertos;
import com.banco.cotizador.dominio.modelo.CotizacionHipotecaria;
public interface RepositorioCotizacionPort { void guardar(CotizacionHipotecaria cotizacion); }
