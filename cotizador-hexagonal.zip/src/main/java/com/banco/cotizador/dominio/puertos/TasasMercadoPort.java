package com.banco.cotizador.dominio.puertos;
public interface TasasMercadoPort { double obtenerTasaAnual(String tipoCliente); }
